package com.example.simplesketch

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class DrawingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val bitmapPaint = Paint(Paint.DITHER_FLAG)
    private var bitmap: Bitmap? = null
    private var canvas: Canvas? = null
    private var path = Path()

    private val pencil = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 12f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        if (w <= 0 || h <= 0) return
        bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        canvas = Canvas(bitmap!!)
        canvas?.drawColor(Color.WHITE)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        bitmap?.let { c.drawBitmap(it, 0f, 0f, bitmapPaint) }
        c.drawPath(path, pencil)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                path = Path()
                path.moveTo(x, y)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                path.lineTo(x, y)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                canvas?.drawPath(path, pencil)
                path.reset()
                invalidate()
                return true
            }
        }
        return true
    }

    fun setPencilColor(color: Int) {
        pencil.color = color
        invalidate()
    }

    fun setPencilSize(size: Float) {
        pencil.strokeWidth = size
        invalidate()
    }

    fun clearCanvas() {
        canvas?.drawColor(Color.WHITE)
        path.reset()
        invalidate()
    }
}
