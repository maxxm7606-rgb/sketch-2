package com.example.simplesketch

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var drawingView: DrawingView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawingView = findViewById(R.id.drawingView)
        val colorButton = findViewById<Button>(R.id.colorButton)
        val sizeSeekBar = findViewById<SeekBar>(R.id.sizeSeekBar)
        val sizeLabel = findViewById<TextView>(R.id.sizeLabel)
        val clearButton = findViewById<Button>(R.id.clearButton)

        colorButton.setTextColor(Color.BLACK)
        colorButton.setBackgroundColor(Color.WHITE)

        colorButton.setOnClickListener {
            val colors = arrayOf(
                "Black", "Red", "Blue", "Green",
                "Yellow", "Purple", "Orange", "Pink", "White"
            )
            val values = intArrayOf(
                Color.BLACK, Color.RED, Color.BLUE, Color.GREEN,
                Color.YELLOW, Color.rgb(128, 0, 128),
                Color.rgb(255, 165, 0), Color.MAGENTA, Color.WHITE
            )

            AlertDialog.Builder(this)
                .setTitle("Choose Pencil Color")
                .setItems(colors) { _, which ->
                    drawingView.setPencilColor(values[which])
                    colorButton.setTextColor(values[which])
                    colorButton.setBackgroundColor(
                        if (values[which] == Color.WHITE) Color.DKGRAY else Color.WHITE
                    )
                }
                .show()
        }

        sizeSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val size = progress + 3
                drawingView.setPencilSize(size.toFloat())
                sizeLabel.text = "Size: $size px"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        clearButton.setOnClickListener {
            drawingView.clearCanvas()
        }
    }
}
