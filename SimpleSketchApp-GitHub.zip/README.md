# Simple Sketch Android App

A minimal Android drawing app with:

- Pencil drawing
- Custom pencil color
- Adjustable pencil size
- Clear canvas
- GitHub Actions cloud build

## Build on GitHub

1. Create a GitHub repository.
2. Upload all files from this project.
3. Push to `main` or `master`.
4. Open **Actions**.
5. Select **Build Android APK**.
6. Wait for the workflow to finish.
7. Open the completed workflow run.
8. Download the **SimpleSketch-debug-APK** artifact.

You can also manually start the build from the **Actions** tab using **Run workflow**.

## Project structure

```text
SimpleSketchApp/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/simplesketch/
│       │   ├── MainActivity.kt
│       │   └── DrawingView.kt
│       └── res/
│           ├── layout/activity_main.xml
│           └── values/styles.xml
├── .github/workflows/build.yml
├── build.gradle.kts
├── gradle.properties
└── settings.gradle.kts
```
